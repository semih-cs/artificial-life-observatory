import { SimulationConfig } from './types.js';

/**
 * Phase 0A default configuration. Every numeric value tagged
 * [OPEN — EMPIRICAL] in the specification is represented here as a
 * [BASELINE] test-fixture placeholder only, per §11.59 / §13.76 / §14 — not
 * scientifically validated, not to be read as final calibration.
 */
export const DEFAULT_SIMULATION_CONFIG: SimulationConfig = {
  simulationVersion: '0A.0.0',
  rootSeed: 1,
  world: {
    width: 200,
    height: 200,
  },
  population: {
    initialPopulationSize: 25,
  },
  neural: {
    hiddenLayerSize: 8,
    initSigma: 0.5,
    neuralParamBounds: { min: -5, max: 5 },
    neuralBootstrapSigma: 0.05,
    maxTurnRate: Math.PI / 6, // radians/tick at output = +-1 [BASELINE]
    eatThreshold: 0.5,
    reproductionActionThreshold: 0.5,
  },
  bootstrap: {
    morphBootstrapSigma: {
      size: 0.02,
      maxSpeed: 0.02,
      visionRange: 0.02,
      visionAngle: 0.02,
      metabolism: 0.02,
    },
    geneBounds: {
      size: { min: 0.5, max: 2.0 },
      maxSpeed: { min: 0.5, max: 3.0 },
      visionRange: { min: 5, max: 60 },
      visionAngle: { min: Math.PI / 6, max: Math.PI },
      metabolism: { min: 0.5, max: 2.0 },
    },
    maxFounderAttempts: 5,
    boundaryMinSeparationFraction: 0.02,
    maxPlacementAttempts: 20,
  },
  energy: {
    energyCapacity: 100,
    configuredInitialEnergy: 50,
    baseMetabolicConstant: 0.05,
    movementEnergyCoefficient: 0.02,
    foodEnergyValue: 20,
    reproductionEnergyThreshold: 60,
    reproductionParentEnergyCost: 30,
  },
  food: {
    initialFoodDensity: 0.02, // food items per unit world area [BASELINE]
    foodRegenPerTick: 1,
    feedingRange: 2,
  },
  mutation: {
    morphologyMutationSigma: {
      size: 0.03,
      maxSpeed: 0.03,
      visionRange: 0.03,
      visionAngle: 0.03,
      metabolism: 0.03,
    },
    neuralMutationSigma: 0.05,
  },
};
