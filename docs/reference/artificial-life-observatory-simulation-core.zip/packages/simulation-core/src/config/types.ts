/**
 * Phase 0A configuration surface. Where the authoritative specification
 * marks a value [BASELINE] / [BASELINE — VERSIONED] / [OPEN — EMPIRICAL], the
 * default in defaults.ts uses a placeholder value and is annotated as such —
 * none of these are presented as validated or final.
 */
export interface WorldConfig {
  /** World is a bounded rectangle, boundaries are hard walls (organisms cannot cross). */
  width: number;
  height: number;
}

export interface PhaseZeroAPopulationConfig {
  /** [BASELINE] N ~ 25, per spec §14.4. */
  initialPopulationSize: number;
}

export interface NeuralConfig {
  hiddenLayerSize: number;
  /** [OPEN — EMPIRICAL] founder weight/bias draw sigma; [BASELINE] placeholder only. */
  initSigma: number;
  /** [BASELINE] bound applied to every weight/bias; out-of-range values are clamped, not rejected. */
  neuralParamBounds: { min: number; max: number };
  /** [OPEN — EMPIRICAL] per specification §13.76 — bootstrap perturbation sigma for neural params. */
  neuralBootstrapSigma: number;
  /** [BASELINE] fixed non-phenotype turn-rate scale (radians/tick at output = ±1). */
  maxTurnRate: number;
  /**
   * [OPEN — EMPIRICAL] action thresholds. The comparator (>=) is [LOCKED]
   * per §11.59; only the magnitude is unresolved. A provisional [BASELINE]
   * test-fixture value is used here for unit tests and must not be read as
   * validated or final.
   */
  eatThreshold: number;
  reproductionActionThreshold: number;
}

export interface MorphologyGeneBounds {
  size: { min: number; max: number };
  maxSpeed: { min: number; max: number };
  visionRange: { min: number; max: number };
  visionAngle: { min: number; max: number };
  metabolism: { min: number; max: number };
}

export interface BootstrapConfig {
  /** [OPEN — EMPIRICAL] per-gene bootstrap perturbation sigma; [BASELINE] placeholders only. */
  morphBootstrapSigma: {
    size: number;
    maxSpeed: number;
    visionRange: number;
    visionAngle: number;
    metabolism: number;
  };
  geneBounds: MorphologyGeneBounds;
  /** [BASELINE] founder candidate retry budget (§13.76 step 4). */
  maxFounderAttempts: number;
  /** [BASELINE] suggested fraction of min(worldWidth, worldHeight) (§13.76). */
  boundaryMinSeparationFraction: number;
  /** [BASELINE] placement retry budget (§13.76 placeWithMinSeparation). */
  maxPlacementAttempts: number;
}

export interface EnergyConfig {
  /** [OPEN — EMPIRICAL] all four coefficients below; [BASELINE] placeholders only. */
  energyCapacity: number;
  configuredInitialEnergy: number;
  baseMetabolicConstant: number;
  movementEnergyCoefficient: number;
  foodEnergyValue: number;
  /** [OPEN — EMPIRICAL] reproduction-energy threshold and post-reproduction parent cost. */
  reproductionEnergyThreshold: number;
  reproductionParentEnergyCost: number;
}

export interface FoodConfig {
  /** [OPEN — EMPIRICAL] both — [BASELINE] placeholders only. */
  initialFoodDensity: number;
  foodRegenPerTick: number;
  /** distance at/under which an organism can feed on a food item (world units). */
  feedingRange: number;
}

export interface MutationConfig {
  /** [OPEN — EMPIRICAL] final mutation magnitudes; [BASELINE] placeholders only. */
  morphologyMutationSigma: {
    size: number;
    maxSpeed: number;
    visionRange: number;
    visionAngle: number;
    metabolism: number;
  };
  neuralMutationSigma: number;
}

export interface SimulationConfig {
  simulationVersion: string;
  rootSeed: number;
  world: WorldConfig;
  population: PhaseZeroAPopulationConfig;
  neural: NeuralConfig;
  bootstrap: BootstrapConfig;
  energy: EnergyConfig;
  food: FoodConfig;
  mutation: MutationConfig;
}
