import { OrganismRuntimeState } from '../organism/types.js';
import { RngStream } from '../rng/rngStream.js';
import { SimulationConfig } from '../config/types.js';
import { mutateGenome } from '../biology/mutation.js';
import { WorldConfigSnapshot } from './types.js';

/**
 * Offspring placement: polar offset from the parent's position, at a fixed
 * [BASELINE] radius range, clamped to the world boundary. Newborn heading is
 * an independent uniform draw (not inherited from the parent's heading).
 */
export function createOffspring(
  parent: OrganismRuntimeState,
  id: number,
  rng: RngStream,
  config: SimulationConfig,
  world: WorldConfigSnapshot
): OrganismRuntimeState {
  const genome = mutateGenome(parent.genome, rng, config.mutation, config.bootstrap.geneBounds, config.neural.neuralParamBounds);

  const placementRadius = config.bootstrap.boundaryMinSeparationFraction * Math.min(world.width, world.height); // [BASELINE] reuse bootstrap separation scale
  const angle = rng.nextInRange(0, 2 * Math.PI);
  const radius = rng.nextInRange(0, placementRadius);
  const x = clamp(parent.x + Math.cos(angle) * radius, 0, world.width);
  const y = clamp(parent.y + Math.sin(angle) * radius, 0, world.height);

  const heading = rng.nextInRange(0, 2 * Math.PI); // independent draw, not inherited

  return {
    id,
    genome,
    x,
    y,
    heading,
    energy: config.energy.configuredInitialEnergy,
    age: 0,
    generationDepth: parent.generationDepth + 1,
    lineageRoot: parent.lineageRoot,
    alive: true,
  };
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}
