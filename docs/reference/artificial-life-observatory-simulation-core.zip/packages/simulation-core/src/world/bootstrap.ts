import { SimulationConfig } from '../config/types.js';
import { createRngStreams, RngStreams, exportRngStreamsState } from '../rng/rngStream.js';
import { generateFounderProfile } from '../genome/founder.js';
import { mutateMorphology, mutateNeural } from '../biology/mutation.js';
import { cloneMorphology, cloneNeural, Genome } from '../genome/types.js';
import { OrganismRuntimeState } from '../organism/types.js';
import { WorldState, FoodItem } from './types.js';

interface Point {
  x: number;
  y: number;
}

/**
 * Deterministic minimum-separation placement (§13.76): accept the first
 * candidate point at/above minSep from every already-placed point; if none
 * within the fixed attempt budget qualifies, deterministically fall back to
 * the best-so-far candidate seen. Never skips an organism.
 */
function placeWithMinSeparation(alreadyPlaced: readonly Point[], streams: RngStreams, config: SimulationConfig): Point {
  const minSep = config.bootstrap.boundaryMinSeparationFraction * Math.min(config.world.width, config.world.height);
  let best: Point | null = null;
  let bestMinDist = -1;

  for (let attempt = 0; attempt < config.bootstrap.maxPlacementAttempts; attempt++) {
    const candidate = streams.bootstrap.uniformPointInWorld(config.world.width, config.world.height);
    const d = alreadyPlaced.length === 0 ? Infinity : Math.min(...alreadyPlaced.map((p) => Math.hypot(candidate.x - p.x, candidate.y - p.y)));
    if (d >= minSep) return candidate;
    if (d > bestMinDist) {
      best = candidate;
      bestMinDist = d;
    }
  }
  return best!;
}

/**
 * Deterministic bootstrap world initialization (§13.76, §20.72 phase 0
 * precursor): runSeed + config -> initial world. Every draw is taken from
 * BootstrapRNG in a fixed, documented order; CanonicalRNG is untouched
 * until the first tick.
 */
export function bootstrapWorld(config: SimulationConfig): WorldState {
  const streams = createRngStreams(config.rootSeed);

  const founderProfile = generateFounderProfile(streams.bootstrap, config.neural.hiddenLayerSize, config.neural, config.bootstrap);

  const organisms: OrganismRuntimeState[] = [];
  const placed: Point[] = [];
  let nextId = 1;

  for (let i = 0; i < config.population.initialPopulationSize; i++) {
    const id = nextId++;

    const morphology = mutateMorphology(
      cloneMorphology(founderProfile.morphology),
      streams.bootstrap,
      config.bootstrap.morphBootstrapSigma,
      config.bootstrap.geneBounds
    );
    const neural = mutateNeural(cloneNeural(founderProfile.neural), streams.bootstrap, config.neural.neuralBootstrapSigma, config.neural.neuralParamBounds);
    const genome: Genome = { morphology, neural };

    const position = placeWithMinSeparation(placed, streams, config);
    placed.push(position);

    const heading = streams.bootstrap.nextInRange(0, 2 * Math.PI);

    organisms.push({
      id,
      genome,
      x: position.x,
      y: position.y,
      heading,
      energy: config.energy.configuredInitialEnergy,
      age: 0,
      generationDepth: 0,
      lineageRoot: id,
      alive: true,
    });
  }

  const food: FoodItem[] = [];
  let nextFoodId = 1;
  const foodCount = Math.round(config.food.initialFoodDensity * config.world.width * config.world.height);
  for (let i = 0; i < foodCount; i++) {
    const p = streams.canonical.uniformPointInWorld(config.world.width, config.world.height);
    food.push({ id: nextFoodId++, x: p.x, y: p.y });
  }

  return {
    tick: 0,
    simulationVersion: config.simulationVersion,
    worldConfig: { width: config.world.width, height: config.world.height },
    organisms,
    food,
    nextOrganismId: nextId,
    nextFoodId,
    rng: exportRngStreamsState(streams),
  };
}
