import { FoodItem, WorldConfigSnapshot } from './types.js';
import { RngStream } from '../rng/rngStream.js';
import { FoodConfig } from '../config/types.js';

/**
 * Food regeneration (§20.72 phase 14). Draws are sequenced after
 * births/removals are applied, on CanonicalRNG. [OPEN — EMPIRICAL] regen rate.
 */
export function regenerateFood(world: WorldConfigSnapshot, rng: RngStream, foodConfig: FoodConfig, nextFoodId: number): { newFood: FoodItem[]; nextFoodId: number } {
  const newFood: FoodItem[] = [];
  let id = nextFoodId;
  for (let i = 0; i < foodConfig.foodRegenPerTick; i++) {
    const p = rng.uniformPointInWorld(world.width, world.height);
    newFood.push({ id: id++, x: p.x, y: p.y });
  }
  return { newFood, nextFoodId: id };
}
