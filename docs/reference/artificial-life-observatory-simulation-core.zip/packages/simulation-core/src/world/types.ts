import { OrganismRuntimeState } from '../organism/types.js';
import { RngStreamsState } from '../rng/rngStream.js';

export interface FoodItem {
  id: number;
  x: number;
  y: number;
}

export interface WorldConfigSnapshot {
  width: number;
  height: number;
}

/** Full canonical world state at a tick boundary. */
export interface WorldState {
  tick: number;
  simulationVersion: string;
  worldConfig: WorldConfigSnapshot;
  organisms: OrganismRuntimeState[];
  food: FoodItem[];
  nextOrganismId: number;
  nextFoodId: number;
  rng: RngStreamsState;
}
