import { WorldState } from './types.js';
import { SimulationConfig } from '../config/types.js';
import { RngStream, RngStreams } from '../rng/rngStream.js';
import { Xoshiro128StarStar } from '../rng/xoshiro128starstar.js';
import { senseOrganism, SenseContext } from '../perception/sense.js';
import { decideAction } from '../actions/decide.js';
import { ActionIntent } from '../actions/types.js';
import { resolveMovement, movementEnergyCost } from '../biology/movement.js';
import { basalEnergyCost, applyEnergyDelta, isDead } from '../biology/energy.js';
import { resolveFeeding } from './foodCompetition.js';
import { isReproductionEligible, applyParentReproductionCost } from '../biology/reproduction.js';
import { createOffspring } from './offspring.js';
import { regenerateFood } from './foodRegen.js';
import { computeTickTelemetry, TickTelemetry } from '../telemetry/types.js';
import { OrganismRuntimeState } from '../organism/types.js';

export interface StepResult {
  world: WorldState;
  telemetry: TickTelemetry;
}

function makeRngStreamsFromState(state: WorldState): RngStreams {
  return {
    bootstrap: rngStreamFromState(state.rng.bootstrap, 'bootstrap'),
    canonical: rngStreamFromState(state.rng.canonical, 'canonical'),
  };
}

function rngStreamFromState(state: { s0: number; s1: number; s2: number; s3: number }, purpose: 'bootstrap' | 'canonical'): RngStream {
  // Construct a stream shell whose internal generator state is overwritten
  // by the caller-supplied snapshot — seed value here is irrelevant since
  // setState replaces it immediately.
  const stream = new RngStream(1, purpose);
  stream.setState(state);
  return stream;
}

/**
 * Normative Phase 0A tick function (§20.72). All living organisms decide
 * from the same logical pre-resolution snapshot; resolution then proceeds
 * in one fixed phase order. This function is the authoritative
 * implementation of that order — phases are not hidden inside per-organism
 * methods, and container iteration position is never used as hidden
 * conflict priority (all ordering is by explicit organism/food ID).
 */
export function stepWorld(state: WorldState, config: SimulationConfig): StepResult {
  const streams = makeRngStreamsFromState(state);

  // Phase: Snapshot. S_t = the world state as received; sensing reads only
  // this snapshot (food, own state) — Phase 0A has no social/organism-to-
  // organism sensing (§11.58), so no other organism's in-progress movement
  // this tick can leak into another organism's perception.
  const senseCtx: SenseContext = {
    world: state.worldConfig,
    food: state.food,
    energyCapacity: config.energy.energyCapacity,
  };

  const living = state.organisms.filter((o) => o.alive);

  // Phase: Sense + Decide. Order does not matter among organisms — each
  // reads only the snapshot and its own state.
  const intents = new Map<number, ActionIntent>();
  for (const o of living) {
    const intent = decideAction(o, senseCtx, config.neural, config.neural.hiddenLayerSize);
    intents.set(o.id, intent);
  }

  // Phase: Movement resolution + movement energy cost + basal metabolism + age.
  for (const o of living) {
    const intent = intents.get(o.id)!;
    resolveMovement(o, intent, state.worldConfig);
    const moveCost = movementEnergyCost(intent, o.genome.morphology.metabolism, config.energy.movementEnergyCoefficient);
    const basalCost = basalEnergyCost(o.genome.morphology.metabolism, config.energy.baseMetabolicConstant);
    applyEnergyDelta(o, -(moveCost + basalCost), config.energy.energyCapacity);
    o.age += 1;
  }

  // Phase: Feeding / same-tick food competition (deterministic, distance +
  // ID tie-break, one food item consumed by at most one organism per tick).
  const feeding = resolveFeeding(living, intents, state.food, config.food.feedingRange);
  const remainingFood = state.food.filter((f) => !feeding.consumedFoodIds.has(f.id));

  // Phase: Energy gain from feeding. This is what makes "feeding rescue"
  // possible: an organism that took lethal movement/basal cost above can
  // still be rescued here, before death resolution runs.
  for (const o of living) {
    const consumedFoodId = feeding.consumptions.get(o.id);
    if (consumedFoodId !== undefined) {
      applyEnergyDelta(o, config.energy.foodEnergyValue, config.energy.energyCapacity);
    }
  }

  // Phase: Reproduction eligibility (computed AFTER energy gain, so a
  // same-tick feeding rescue can also enable same-tick reproduction).
  const eligibleParents = living
    .filter((o) => isReproductionEligible(o, intents.get(o.id)!.reproduceRequested, config.energy))
    .sort((a, b) => a.id - b.id); // parent-ID-ordered resolution and RNG consumption

  // Phase: Reproduction resolution + child creation (mutation + placement),
  // strictly in ascending parent-ID order so RNG consumption order is a
  // pure function of organism ID, never of array/iteration position.
  const children: OrganismRuntimeState[] = [];
  let nextOrganismId = state.nextOrganismId;
  for (const parent of eligibleParents) {
    const child = createOffspring(parent, nextOrganismId, streams.canonical, config, state.worldConfig);
    nextOrganismId += 1;
    children.push(child);
    // Phase: Parent cost, applied immediately after this parent's child is created.
    applyParentReproductionCost(parent, config.energy);
  }

  // Phase: Death resolution (after feeding/reproduction, so a rescued
  // organism that fed and/or reproduced this tick is correctly alive).
  for (const o of living) {
    if (isDead(o, config.energy)) {
      o.alive = false;
    }
  }

  // Phase: Apply births/removals. Dead organisms are dropped from the
  // canonical list; new children are appended, sorted by ID for a
  // deterministic canonical ordering.
  const survivors = state.organisms.filter((o) => o.alive);
  const allOrganisms = [...survivors, ...children].sort((a, b) => a.id - b.id);

  // Phase: Food regeneration, sequenced after births/removals, on CanonicalRNG.
  const regen = regenerateFood(state.worldConfig, streams.canonical, config.food, state.nextFoodId);
  const allFood = [...remainingFood, ...regen.newFood].sort((a, b) => a.id - b.id);

  // Phase: Telemetry (observational only; never feeds back into biology).
  const meanEnergy = allOrganisms.length > 0 ? allOrganisms.reduce((s, o) => s + o.energy, 0) / allOrganisms.length : 0;
  const telemetry = computeTickTelemetry(state.tick, allOrganisms.length, allFood.length, children.length, living.length - survivors.length, meanEnergy);

  // Phase: Advance tick.
  const newWorld: WorldState = {
    tick: state.tick + 1,
    simulationVersion: state.simulationVersion,
    worldConfig: state.worldConfig,
    organisms: allOrganisms,
    food: allFood,
    nextOrganismId,
    nextFoodId: regen.nextFoodId,
    rng: { bootstrap: streams.bootstrap.getState(), canonical: streams.canonical.getState() },
  };

  return { world: newWorld, telemetry };
}

// re-exported for callers that need to construct a fresh generator directly
export { Xoshiro128StarStar };
