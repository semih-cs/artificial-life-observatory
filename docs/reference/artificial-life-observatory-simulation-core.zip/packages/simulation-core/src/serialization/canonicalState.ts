import { WorldState } from '../world/types.js';

/**
 * Canonical, deterministically-ordered serialization of a WorldState, for
 * hashing/comparison in the determinism regression test. Includes only
 * future-affecting state: organism/food arrays sorted by ID, genome arrays
 * in fixed index order (already guaranteed by the genome types), RNG state,
 * tick, and simulationVersion. Deliberately excludes anything observational/
 * debug-only that cannot influence future biology (telemetry is excluded
 * entirely — see telemetry/types.ts).
 */
export function canonicalizeWorldState(world: WorldState): unknown {
  const organisms = [...world.organisms]
    .sort((a, b) => a.id - b.id)
    .map((o) => ({
      id: o.id,
      x: o.x,
      y: o.y,
      heading: o.heading,
      energy: o.energy,
      age: o.age,
      generationDepth: o.generationDepth,
      lineageRoot: o.lineageRoot,
      alive: o.alive,
      genome: {
        morphology: { ...o.genome.morphology },
        neural: {
          inputHiddenWeights: [...o.genome.neural.inputHiddenWeights],
          hiddenBiases: [...o.genome.neural.hiddenBiases],
          hiddenOutputWeights: [...o.genome.neural.hiddenOutputWeights],
          outputBiases: [...o.genome.neural.outputBiases],
        },
      },
    }));

  const food = [...world.food].sort((a, b) => a.id - b.id).map((f) => ({ id: f.id, x: f.x, y: f.y }));

  return {
    simulationVersion: world.simulationVersion,
    tick: world.tick,
    worldConfig: { ...world.worldConfig },
    nextOrganismId: world.nextOrganismId,
    nextFoodId: world.nextFoodId,
    organisms,
    food,
    rng: {
      bootstrap: { ...world.rng.bootstrap },
      canonical: { ...world.rng.canonical },
    },
  };
}

/**
 * A stable string form of the canonical state — deterministic key ordering
 * (object keys above are inserted in a fixed order, and JSON.stringify
 * preserves insertion order for string keys) suitable for a simple string-
 * equality determinism check or as input to an external hash function.
 */
export function canonicalStateString(world: WorldState): string {
  return JSON.stringify(canonicalizeWorldState(world));
}

/**
 * A small, dependency-free deterministic hash (FNV-1a, 32-bit) of the
 * canonical state string. Non-cryptographic by design — this is a
 * reproducibility fingerprint for tests/telemetry, not a security primitive.
 */
export function canonicalStateHash(world: WorldState): string {
  const str = canonicalStateString(world);
  let hash = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0).toString(16).padStart(8, '0');
}
