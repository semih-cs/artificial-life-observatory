import { Genome, MorphologyGenome, NeuralGenome, NEURAL_INPUT_SIZE, NEURAL_OUTPUT_SIZE } from './types.js';
import { RngStream } from '../rng/rngStream.js';
import { NeuralConfig, BootstrapConfig } from '../config/types.js';
import { evaluateNetwork } from '../neural/network.js';

/**
 * Founder Neural Genome generation & deterministic bootstrap procedure
 * (§13.76, [LOCKED] procedure / [BASELINE] fixture values). Generates one
 * candidate at a time from BootstrapRNG, accepts the first that passes
 * mechanical validity + the five-check minimal-viability smoke test.
 * Candidates are never compared to each other and never run through a
 * trajectory/fitness preview.
 */

function drawNeuralGenome(rng: RngStream, hiddenSize: number, sigma: number): NeuralGenome {
  const draw = (n: number) => Array.from({ length: n }, () => rng.gaussian(0, sigma));
  // fixed parameter order: input->hidden weights, hidden biases, hidden->output weights, output biases
  return {
    inputHiddenWeights: draw(hiddenSize * NEURAL_INPUT_SIZE),
    hiddenBiases: draw(hiddenSize),
    hiddenOutputWeights: draw(NEURAL_OUTPUT_SIZE * hiddenSize),
    outputBiases: draw(NEURAL_OUTPUT_SIZE),
  };
}

function mechanicalValidityCheck(genome: NeuralGenome, hiddenSize: number, bounds: { min: number; max: number }): NeuralGenome {
  const clampArr = (arr: readonly number[]) =>
    arr.map((v) => {
      const finite = Number.isFinite(v) ? v : 0;
      return Math.max(bounds.min, Math.min(bounds.max, finite));
    });
  if (genome.inputHiddenWeights.length !== hiddenSize * NEURAL_INPUT_SIZE) throw new Error('founder: dimensionality mismatch (input->hidden)');
  if (genome.hiddenBiases.length !== hiddenSize) throw new Error('founder: dimensionality mismatch (hidden biases)');
  if (genome.hiddenOutputWeights.length !== NEURAL_OUTPUT_SIZE * hiddenSize) throw new Error('founder: dimensionality mismatch (hidden->output)');
  if (genome.outputBiases.length !== NEURAL_OUTPUT_SIZE) throw new Error('founder: dimensionality mismatch (output biases)');
  return {
    inputHiddenWeights: clampArr(genome.inputHiddenWeights),
    hiddenBiases: clampArr(genome.hiddenBiases),
    hiddenOutputWeights: clampArr(genome.hiddenOutputWeights),
    outputBiases: clampArr(genome.outputBiases),
  };
}

/** Fixed synthetic probe set (§13.76 hotfix): one vector per named check. */
function probeSet(): { name: string; input: number[] }[] {
  return [
    { name: 'food-ahead-close', input: [1, 0.1, 0, 0.5, 0, 0.5] },
    { name: 'food-ahead-far', input: [1, 0.9, 0, 0.5, 0, 0.5] },
    { name: 'eat-ready', input: [1, 0.02, 0, 0.5, 0, 0.5] },
    { name: 'reproduce-diagnostic', input: [0, 0, 0, 0.5, 0, 0.95] },
    { name: 'neutral', input: [0, 0, 0, 0.5, 0, 0.5] },
  ];
}

export interface ViabilityResult {
  pass: boolean;
  checks: { nonDegenerate: boolean; movementPossible: boolean; foodApproachable: boolean; eatingPossible: boolean; reproductionPossible: boolean };
}

/**
 * Five-check minimal-viability smoke test (§13.76 hotfix): binary pass/fail
 * against the fixed probe set above. No ranking, no scoring, no comparison
 * between candidates.
 */
export function minimalViabilityScreen(genome: NeuralGenome, hiddenSize: number, neuralConfig: NeuralConfig): ViabilityResult {
  const probes = probeSet();
  const outputs = probes.map((p) => ({ name: p.name, out: evaluateNetwork(genome, p.input, hiddenSize) }));

  const forwardValues = outputs.map((o) => o.out.forward);
  const nonDegenerate = new Set(forwardValues.map((v) => v.toFixed(6))).size > 1 || outputs.some((o) => o.out.eat !== o.out.forward);

  const movementPossible = outputs.some((o) => o.out.forward > 0.5);

  const foodAheadClose = outputs.find((o) => o.name === 'food-ahead-close')!.out;
  const foodAheadFar = outputs.find((o) => o.name === 'food-ahead-far')!.out;
  // "moves toward, not away from" food directly ahead (foodAngle=0): a
  // non-negative turn bias is acceptable (heading straight at it is fine);
  // a strong negative turn (steering hard away) fails this smoke check.
  const foodApproachable = foodAheadClose.turn > -0.5 && foodAheadFar.turn > -0.5;

  const eatingPossible = outputs.find((o) => o.name === 'eat-ready')!.out.eat >= neuralConfig.eatThreshold;
  const reproductionPossible = outputs.find((o) => o.name === 'reproduce-diagnostic')!.out.reproduce >= neuralConfig.reproductionActionThreshold;

  const pass = nonDegenerate && movementPossible && foodApproachable && eatingPossible && reproductionPossible;
  return { pass, checks: { nonDegenerate, movementPossible, foodApproachable, eatingPossible, reproductionPossible } };
}

export interface FounderGenerationResult {
  neural: NeuralGenome;
  attempts: number;
  lastViability: ViabilityResult;
}

/**
 * Generate the Founder Neural Genome: draw -> mechanical validity ->
 * five-check viability screen -> retry on the SAME BootstrapRNG stream
 * (never rewound, never re-rolled) up to maxFounderAttempts. Exhausting all
 * attempts is a configuration error, thrown rather than silently retried
 * indefinitely.
 */
export function generateFounderNeuralGenome(rng: RngStream, hiddenSize: number, neuralConfig: NeuralConfig, bootstrapConfig: BootstrapConfig): FounderGenerationResult {
  let lastViability: ViabilityResult | null = null;
  for (let attempt = 1; attempt <= bootstrapConfig.maxFounderAttempts; attempt++) {
    const raw = drawNeuralGenome(rng, hiddenSize, neuralConfig.initSigma);
    let candidate: NeuralGenome;
    try {
      candidate = mechanicalValidityCheck(raw, hiddenSize, neuralConfig.neuralParamBounds);
    } catch {
      continue; // structurally invalid; draw next candidate
    }
    const viability = minimalViabilityScreen(candidate, hiddenSize, neuralConfig);
    lastViability = viability;
    if (viability.pass) {
      return { neural: candidate, attempts: attempt, lastViability: viability };
    }
  }
  throw new Error(
    `generateFounderNeuralGenome: exhausted maxFounderAttempts (${bootstrapConfig.maxFounderAttempts}) without a viable candidate — ` +
      'this indicates a degenerate initSigma or probe set configuration, per §13.76, and should be fixed directly, not retried indefinitely. ' +
      `Last viability: ${JSON.stringify(lastViability?.checks)}`
  );
}

export function founderMorphology(bounds: BootstrapConfig['geneBounds']): MorphologyGenome {
  // Founder morphology is the midpoint of each gene's bounds — a fixed,
  // documented, non-adaptive choice (not drawn from RNG: it is the single
  // reference point every bootstrap organism perturbs away from).
  const mid = (b: { min: number; max: number }) => (b.min + b.max) / 2;
  return {
    size: mid(bounds.size),
    maxSpeed: mid(bounds.maxSpeed),
    visionRange: mid(bounds.visionRange),
    visionAngle: mid(bounds.visionAngle),
    metabolism: mid(bounds.metabolism),
  };
}

export function generateFounderProfile(rng: RngStream, hiddenSize: number, neuralConfig: NeuralConfig, bootstrapConfig: BootstrapConfig): Genome {
  const { neural } = generateFounderNeuralGenome(rng, hiddenSize, neuralConfig, bootstrapConfig);
  const morphology = founderMorphology(bootstrapConfig.geneBounds);
  return { morphology, neural };
}
