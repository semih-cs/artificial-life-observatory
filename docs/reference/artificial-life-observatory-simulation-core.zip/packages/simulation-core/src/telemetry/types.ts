/**
 * Minimal Phase 0A telemetry — observational only, must never influence
 * future biology (§20.72 phase 15, "Telemetry"). Not included in the
 * canonical-state hash (serialization/canonicalState.ts).
 */
export interface TickTelemetry {
  tick: number;
  populationCount: number;
  totalFood: number;
  births: number;
  deaths: number;
  meanEnergy: number;
}

export function computeTickTelemetry(
  tick: number,
  populationCount: number,
  totalFood: number,
  births: number,
  deaths: number,
  meanEnergy: number
): TickTelemetry {
  return { tick, populationCount, totalFood, births, deaths, meanEnergy };
}
