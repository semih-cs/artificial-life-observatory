import { Genome } from '../genome/types.js';

/**
 * Runtime (per-tick, mutable) organism state — structurally separate from
 * the heritable Genome. Update logic in `biology/` mutates fields on this
 * object; it must never reach into `genome` and mutate it.
 */
export interface OrganismRuntimeState {
  id: number;
  readonly genome: Genome;
  x: number;
  y: number;
  /** heading in radians, [0, 2*PI) */
  heading: number;
  energy: number;
  age: number;
  generationDepth: number;
  lineageRoot: number;
  alive: boolean;
}

export function isAlive(o: OrganismRuntimeState): boolean {
  return o.alive;
}
