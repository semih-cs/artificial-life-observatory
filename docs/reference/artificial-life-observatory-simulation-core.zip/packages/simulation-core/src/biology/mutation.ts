import { Genome, MorphologyGenome, NeuralGenome, cloneNeural } from '../genome/types.js';
import { RngStream } from '../rng/rngStream.js';
import { MutationConfig } from '../config/types.js';
import { MorphologyGeneBounds } from '../config/types.js';

/**
 * Morphology mutation (§20.72 phase 10, child creation): Gaussian
 * perturbation per gene, fixed gene order, clamped to bounds. This mutates
 * a NEWLY CREATED child genome only — never an existing organism's stored
 * genome.
 */
export function mutateMorphology(parent: MorphologyGenome, rng: RngStream, sigma: MutationConfig['morphologyMutationSigma'], bounds: MorphologyGeneBounds): MorphologyGenome {
  const clampTo = (v: number, b: { min: number; max: number }) => Math.max(b.min, Math.min(b.max, v));
  return {
    size: clampTo(parent.size + rng.gaussian(0, sigma.size), bounds.size),
    maxSpeed: clampTo(parent.maxSpeed + rng.gaussian(0, sigma.maxSpeed), bounds.maxSpeed),
    visionRange: clampTo(parent.visionRange + rng.gaussian(0, sigma.visionRange), bounds.visionRange),
    visionAngle: clampTo(parent.visionAngle + rng.gaussian(0, sigma.visionAngle), bounds.visionAngle),
    metabolism: clampTo(parent.metabolism + rng.gaussian(0, sigma.metabolism), bounds.metabolism),
  };
}

/** Neural mutation: independent Gaussian perturbation of every weight/bias, fixed param order. */
export function mutateNeural(parent: NeuralGenome, rng: RngStream, sigma: number, bounds: { min: number; max: number }): NeuralGenome {
  const clampTo = (v: number) => Math.max(bounds.min, Math.min(bounds.max, v));
  const perturb = (arr: readonly number[]) => arr.map((v) => clampTo(v + rng.gaussian(0, sigma)));
  return {
    inputHiddenWeights: perturb(parent.inputHiddenWeights),
    hiddenBiases: perturb(parent.hiddenBiases),
    hiddenOutputWeights: perturb(parent.hiddenOutputWeights),
    outputBiases: perturb(parent.outputBiases),
  };
}

export function mutateGenome(
  parent: Genome,
  rng: RngStream,
  mutationConfig: MutationConfig,
  bounds: MorphologyGeneBounds,
  neuralBounds: { min: number; max: number }
): Genome {
  return {
    morphology: mutateMorphology(parent.morphology, rng, mutationConfig.morphologyMutationSigma, bounds),
    neural: mutateNeural(parent.neural, rng, mutationConfig.neuralMutationSigma, neuralBounds),
  };
}

// re-exported for callers that want an unmutated clone alongside mutation (offspring creation helper)
export { cloneNeural };
