import { OrganismRuntimeState } from '../organism/types.js';
import { EnergyConfig } from '../config/types.js';

/** Basal energy cost (§20.72 phase 5 companion, applied once per tick). [BASELINE]. */
export function basalEnergyCost(metabolism: number, baseMetabolicConstant: number): number {
  return metabolism * baseMetabolicConstant;
}

export function applyEnergyDelta(organism: OrganismRuntimeState, delta: number, cap: number): void {
  organism.energy = Math.max(0, Math.min(cap, organism.energy + delta));
}

/** Death condition (§20.72 phase 11): energy <= 0. [LOCKED] comparator, matching the
 * general eat/reproduce >= convention inverted for a "has died" predicate. */
export function isDead(organism: OrganismRuntimeState, energyConfig: EnergyConfig): boolean {
  return organism.energy <= 0;
}
