import { OrganismRuntimeState } from '../organism/types.js';
import { EnergyConfig } from '../config/types.js';

/**
 * Reproduction eligibility (§20.72 phase 8): the organism requested
 * reproduce AND has enough energy. Both are required — a reproduce-output
 * above threshold with insufficient energy is not eligible.
 */
export function isReproductionEligible(organism: OrganismRuntimeState, reproduceRequested: boolean, energyConfig: EnergyConfig): boolean {
  return reproduceRequested && organism.energy >= energyConfig.reproductionEnergyThreshold;
}

/** Parent cost applied on successful reproduction (§20.72 phase 10). [OPEN — EMPIRICAL] magnitude. */
export function applyParentReproductionCost(organism: OrganismRuntimeState, energyConfig: EnergyConfig): void {
  organism.energy = Math.max(0, organism.energy - energyConfig.reproductionParentEnergyCost);
}
