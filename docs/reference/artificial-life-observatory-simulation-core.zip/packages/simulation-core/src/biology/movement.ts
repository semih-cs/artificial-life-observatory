import { OrganismRuntimeState } from '../organism/types.js';
import { WorldConfigSnapshot } from '../world/types.js';
import { ActionIntent } from '../actions/types.js';

/**
 * Movement resolution (§20.72 phase 4). Requested speed/turn are already
 * phenotype-scaled by decide.ts. Position is clamped to the world's hard
 * boundary — organisms cannot cross the perimeter.
 */
export function resolveMovement(organism: OrganismRuntimeState, intent: ActionIntent, world: WorldConfigSnapshot): void {
  organism.heading = wrapHeading(organism.heading + intent.requestedTurnRate);
  const dx = Math.cos(organism.heading) * intent.requestedForwardSpeed;
  const dy = Math.sin(organism.heading) * intent.requestedForwardSpeed;
  organism.x = clamp(organism.x + dx, 0, world.width);
  organism.y = clamp(organism.y + dy, 0, world.height);
}

/** Movement energy cost (§20.72 phase 5). [BASELINE] linear in distance moved and metabolism. */
export function movementEnergyCost(intent: ActionIntent, metabolism: number, coefficient: number): number {
  return intent.requestedForwardSpeed * metabolism * coefficient;
}

function wrapHeading(h: number): number {
  const twoPi = 2 * Math.PI;
  let r = h % twoPi;
  if (r < 0) r += twoPi;
  return r;
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}
