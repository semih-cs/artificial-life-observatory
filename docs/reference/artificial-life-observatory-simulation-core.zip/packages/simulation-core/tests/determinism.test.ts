import { describe, it, expect } from 'vitest';
import { bootstrapWorld } from '../src/world/bootstrap.js';
import { stepWorld } from '../src/world/stepWorld.js';
import { canonicalStateHash, canonicalStateString } from '../src/serialization/canonicalState.js';
import { DEFAULT_SIMULATION_CONFIG } from '../src/config/defaults.js';
import { SimulationConfig } from '../src/config/types.js';
import { WorldState } from '../src/world/types.js';

function runTicks(config: SimulationConfig, tickCount: number): WorldState {
  let world = bootstrapWorld(config);
  for (let i = 0; i < tickCount; i++) {
    world = stepWorld(world, config).world;
  }
  return world;
}

describe('determinism regression (first full-system acceptance gate)', () => {
  const config = DEFAULT_SIMULATION_CONFIG;

  it('tick 0: two independent bootstraps of the same seed match exactly', () => {
    const a = runTicks(config, 0);
    const b = runTicks(config, 0);
    expect(canonicalStateHash(a)).toEqual(canonicalStateHash(b));
  });

  it('an early tick (tick 1): two independent runs match exactly', () => {
    const a = runTicks(config, 1);
    const b = runTicks(config, 1);
    expect(canonicalStateHash(a)).toEqual(canonicalStateHash(b));
  });

  it('a later tick (tick 200, after food/reproduction/mutation activity is possible): two independent runs match exactly', () => {
    const a = runTicks(config, 200);
    const b = runTicks(config, 200);
    expect(canonicalStateHash(a)).toEqual(canonicalStateHash(b));
    expect(canonicalStateString(a)).toEqual(canonicalStateString(b));
  });

  it('same seed, same config, same tick count -> identical population dynamics summary', () => {
    const a = runTicks(config, 200);
    const b = runTicks(config, 200);
    expect(a.organisms.length).toEqual(b.organisms.length);
    expect(a.food.length).toEqual(b.food.length);
    expect(a.nextOrganismId).toEqual(b.nextOrganismId);
    expect(a.tick).toEqual(200);
  });

  it('a different seed produces a different trajectory by a later tick', () => {
    const a = runTicks(config, 200);
    const b = runTicks({ ...config, rootSeed: config.rootSeed + 1 }, 200);
    expect(canonicalStateHash(a)).not.toEqual(canonicalStateHash(b));
  });

  it('running 200 ticks incrementally (one at a time) matches running them in one pass', () => {
    // "one pass" here just means the same loop; the real assertion is that
    // stepWorld is a pure function of (state, config) with no hidden mutable
    // module-level state carried between calls to two independently
    // constructed worlds.
    const worldA = bootstrapWorld(config);
    let a = worldA;
    for (let i = 0; i < 200; i++) a = stepWorld(a, config).world;

    const worldB = bootstrapWorld(config);
    let b = worldB;
    for (let i = 0; i < 200; i++) b = stepWorld(b, config).world;

    expect(canonicalStateHash(a)).toEqual(canonicalStateHash(b));
  });

  it('simulation runs for many ticks without throwing and population never goes negative', () => {
    let world = bootstrapWorld(config);
    for (let i = 0; i < 500; i++) {
      const result = stepWorld(world, config);
      world = result.world;
      expect(world.organisms.length).toBeGreaterThanOrEqual(0);
      expect(result.telemetry.populationCount).toBe(world.organisms.length);
    }
  });
});
